from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from app.configurations.settings import settings

engine = create_engine(settings.DATABASE_URL, echo=True)

SessionLocal = sessionmaker(
    autocommit=False,
    autoflush=False,
    bind=engine
)